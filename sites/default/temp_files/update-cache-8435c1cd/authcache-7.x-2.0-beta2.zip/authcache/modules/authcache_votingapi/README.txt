Instructions
============

This module does not expose any configuration. If enabled the browser cache of
the triggering user is invalidated whenever votes are added / removed.

This module works best together with Authcache Field and fields used to store
user-ratings (e.g. Fivestar).
