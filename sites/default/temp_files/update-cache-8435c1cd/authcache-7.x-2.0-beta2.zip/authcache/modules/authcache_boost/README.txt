INSTALLATION
============

* Install and enable authcache, boost and authcache_boost modules.
* Apply patch from http://drupal.org/node/1942848 to boost.
* Generate and install new .htaccess rules with the included boost rule
  generator
