NOTES
=====

The drupal core Forum module displays relative times (posted x minutes ago) in
various places. In order to make them cacheable it is recommended to use the
Timeago module.

https://drupal.org/project/timeago

As of this writing Forum support is not yet included in the Timeago module
(version 7.x-2.2). Please visit the following issue in order to figure out
whether patching of the most recent version is still necessary.

https://drupal.org/node/2136643
